/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.springct;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

/**
 *
 * @author Swapnil
 */
public class Demo {
    private static Session SessionFactory;
    
    public static void main(String[] args)
    {
        Student s=new Student();
        s.setSname("Rohit");
        s.setEmail("rohit123");
        s.setPhoneno("1234567890");
        
        Course c1=new Course();
        c1.setName("java");
        c1.setProfname("jadhav");
        c1.setDescription("full stack");
        c1.setStud(s);
        
        Course c2=new Course();
        c2.setName("python");
        c2.setProfname("patil");
        c2.setDescription("web technology");
        c2.setStud(s);
        
        SessionFactory sessionFactory=NewHibernateUtil.getSessionFactory();
        SessionFactory=sessionFactory.openSession();
        Transaction transaction=session.begingTransaction();
        
        session.save(c1);
        session.save(c2);
        
        transaction.commit();
  
        
        
        
    }
}
